<?php
declare(strict_types=1);
require_once __DIR__ . '/inventory_helpers.php';
require_once __DIR__ . '/credential_helpers.php';
require_once __DIR__ . '/credential_totp_helpers.php';
require_once __DIR__ . '/employee_software_credentials.php';
require_once __DIR__ . '/hardware_assignment_helpers.php';
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') requirePermission('employees', 'view');
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $postedAction = trim((string)($_POST['credential_action'] ?? '')) ?: (string)($_POST['action'] ?? '');
    $credentialPermission = employeeCredentialActionPermission($postedAction);
    [$resource, $operation] = $credentialPermission ?? match ($postedAction) {
        'hardware_assign', 'hardware_close' => ['hardware', 'hardware_assignment'],
        'hardware_replace' => ['hardware', 'hardware_assignment'],
        'software_add' => ['software', 'add'],
        'software_edit' => ['software', 'edit'],
        'software_uninstall' => ['software', 'delete'],
        default => ['employees', 'edit'],
    };
    requirePermission($resource, $operation);
    verifyCsrf();
}
$db = db();
$employeeId = filter_var($_GET['id'] ?? $_POST['employee_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
if (!$employeeId) { http_response_code(404); exit('Employee not found.'); }
$employeeQuery = $db->prepare('SELECT id,employee_id,full_name,department,location,email,active,created_at,updated_at FROM employees WHERE id=?');
$employeeQuery->execute([$employeeId]);
$employee = $employeeQuery->fetch();
if (!$employee) { http_response_code(404); exit('Employee not found.'); }
$pageTitle = 'Employee Details';
$activeTab = in_array($_GET['tab'] ?? '', ['software', 'hardware'], true) ? (string)$_GET['tab'] : 'hardware';
$canViewHardware = canViewResource('hardware');
$canAssignHardware = canPerform('hardware', 'hardware_assignment');
$canViewSoftware = canViewResource('software');
$canAddSoftware = canPerform('software', 'add');
$canEditSoftware = canPerform('software', 'edit');
$canDeleteSoftware = canPerform('software', 'delete');
$credentialTwoFactorReady = credentialTotpSessionVerified();
$canViewCredentials = canViewResource('credentials') && $credentialTwoFactorReady;
$canCreateCredentials = canPerform('credentials', 'create') && $credentialTwoFactorReady;
$canEditCredentials = canPerform('credentials', 'edit') && $credentialTwoFactorReady;
$canDeleteCredentials = canPerform('credentials', 'delete') && $credentialTwoFactorReady;
$canViewSoftwareTab = $canViewSoftware;
$canRevealCredentials = canPerform('credentials', 'reveal') && $credentialTwoFactorReady;
$canManageEmployeeCredentials = $canViewCredentials || $canCreateCredentials || $canEditCredentials || $canDeleteCredentials || $canRevealCredentials;
$canCreateEmployeeCredentials = $canCreateCredentials && (canAdmin() || credentialCanAccessDepartment(credentialDepartmentForEmployee((int)$employeeId)));
if (($activeTab === 'hardware' && !$canViewHardware) || ($activeTab === 'software' && !$canViewSoftwareTab)) $activeTab = $canViewHardware ? 'hardware' : 'software';

function recordEmployeeAssetStock(PDO $db, int $productId, string $type, string $reason, string $notes, int $actor, ?string $unitCost = null): void {
    $lock=$db->prepare('SELECT id FROM products WHERE id=? FOR UPDATE');$lock->execute([$productId]);if(!$lock->fetchColumn())throw new DomainException('The hardware product is unavailable.');
    $last=$db->prepare('SELECT new_quantity FROM inventory_transactions WHERE product_id=? ORDER BY id DESC LIMIT 1');$last->execute([$productId]);$previous=(int)($last->fetchColumn()?:0);$movement=calculateInventoryChange($previous,$type,1);
    $totalCost = $unitCost === null ? null : calculateTransactionPrice(1,$unitCost)['total_price'];
    $stmt=$db->prepare('INSERT INTO inventory_transactions(product_id,transaction_type,quantity,previous_quantity,new_quantity,reason,unit_price,total_price,notes,created_by,transaction_at) VALUES(?,?,?,?,?,?,?,?,?,?,NOW())');
    $stmt->execute([$productId,$type,$movement['recorded_quantity'],$previous,$movement['new_stock'],$reason,$unitCost,$totalCost,$notes,$actor]);
    recalculateInventoryMonths($productId);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $postedAction;
    try {
        $db->beginTransaction();
        $lockedEmployee = $db->prepare('SELECT id,employee_id,full_name,department,location FROM employees WHERE id=? FOR UPDATE');
        $lockedEmployee->execute([$employeeId]);
        $person = $lockedEmployee->fetch();
        if (!$person) throw new DomainException('Employee was not found.');
        $actor = (int)currentUser()['id'];

        if ($action === 'hardware_assign') {
            $assetId = filter_var($_POST['asset_id'] ?? null, FILTER_VALIDATE_INT, ['options'=>['min_range'=>1]]);
            $condition = (string)($_POST['condition'] ?? '');
            if (!$assetId || !in_array($condition, ['New','Good','Fair','Poor'], true)) throw new DomainException('Choose an available asset and a valid condition.');
            $assetQ = $db->prepare('SELECT ia.id,ia.product_id,ia.asset_tag,ia.serial_number,ia.acquisition_unit_cost,ia.status,p.name product_name,p.category_id FROM inventory_assets ia JOIN products p ON p.id=ia.product_id WHERE ia.id=? FOR UPDATE');
            $assetQ->execute([$assetId]); $asset = $assetQ->fetch();
            if (!$asset) throw new DomainException('Choose a registered hardware asset.');
            $activeQ = $db->prepare("SELECT id FROM assignments WHERE asset_id=? AND status='assigned' LIMIT 1 FOR UPDATE");
            $activeQ->execute([$assetId]);
            $mappingQ=$db->prepare('SELECT assignment_id FROM active_hardware_assignments WHERE asset_id=? FOR UPDATE');$mappingQ->execute([$assetId]);
            if ($asset['status']!=='available'||$activeQ->fetchColumn()||$mappingQ->fetchColumn()) throw new DomainException('This hardware is already assigned to another employee.');
            $insert = $db->prepare("INSERT INTO assignments(product_id,asset_id,quantity,assigned_to,employee_id,employee_record_id,department,location,assigned_by,status,condition_at_assignment,notes) VALUES(?,?,1,?,?,?,?,?,?, 'assigned',?,?)");
            $insert->execute([$asset['product_id'],$assetId,$person['full_name'],$person['employee_id'],$employeeId,$person['department'],$person['location'],$actor,$condition,trim((string)($_POST['notes']??''))?:null]);
            $assignmentId=(int)$db->lastInsertId();
            $db->prepare('INSERT INTO active_hardware_assignments(asset_id,assignment_id) VALUES(?,?)')->execute([$assetId,$assignmentId]);
            recordEmployeeAssetStock($db,(int)$asset['product_id'],'out','Assignment → '.$person['full_name'].' ('.$person['employee_id'].')','Hardware assignment #'.$assignmentId.'; asset #'.$assetId,$actor,$asset['acquisition_unit_cost']===null?null:(string)$asset['acquisition_unit_cost']);
            $db->prepare("UPDATE inventory_assets SET status='assigned',location=? WHERE id=?")->execute([$person['location'],$assetId]);
            $db->prepare("INSERT INTO hardware_assignment_history(employee_id,assignment_id,action,reason,new_asset_id,performed_by) VALUES(?,?,'assigned',?,?,?)")
                ->execute([$employeeId,$assignmentId,trim((string)($_POST['reason']??''))?:null,$assetId,$actor]);
            audit('hardware_assigned','assignment',$assignmentId,'Asset #'.$assetId.' '.$asset['product_name'].' assigned to '.$person['full_name']);
            setFlash('success','Hardware assigned successfully.');
        } elseif ($action === 'hardware_replace') {
            $oldId=filter_var($_POST['assignment_id']??null,FILTER_VALIDATE_INT,['options'=>['min_range'=>1]]);
            $newId=filter_var($_POST['asset_id']??null,FILTER_VALIDATE_INT,['options'=>['min_range'=>1]]);
            $reason=trim((string)($_POST['reason']??''));
            if (!$oldId||!$newId||$oldId===$newId||$reason==='') throw new DomainException('Select a different available asset and enter a replacement reason.');
            $oldQ=$db->prepare("SELECT a.id,a.asset_id,a.product_id,ia.acquisition_unit_cost FROM assignments a JOIN inventory_assets ia ON ia.id=a.asset_id WHERE a.id=? AND a.employee_record_id=? AND a.status='assigned' AND a.asset_id IS NOT NULL FOR UPDATE");
            $oldQ->execute([$oldId,$employeeId]);$old=$oldQ->fetch();if(!$old)throw new DomainException('Select an active registered hardware assignment to replace.');
            $newQ=$db->prepare("SELECT ia.id,ia.product_id,ia.acquisition_unit_cost,p.name product_name FROM inventory_assets ia JOIN products p ON p.id=ia.product_id WHERE ia.id=? AND ia.status='available' FOR UPDATE");
            $newQ->execute([$newId]);$new=$newQ->fetch();if(!$new)throw new DomainException('The replacement asset is no longer available.');
            $activeQ=$db->prepare("SELECT id FROM assignments WHERE asset_id=? AND status='assigned' LIMIT 1 FOR UPDATE");$activeQ->execute([$newId]);if($activeQ->fetchColumn())throw new DomainException('The replacement asset is already assigned.');
            $db->prepare('DELETE FROM active_hardware_assignments WHERE assignment_id=?')->execute([$oldId]);
            $db->prepare("UPDATE assignments SET status='replaced',returned_at=NOW() WHERE id=? AND status='assigned'")->execute([$oldId]);
            if($old['asset_id'])$db->prepare("UPDATE inventory_assets SET status='available' WHERE id=?")->execute([$old['asset_id']]);
            recordEmployeeAssetStock($db,(int)$old['product_id'],'in','Hardware returned for replacement → '.$person['full_name'],'Replacement of assignment #'.$oldId,$actor,$old['acquisition_unit_cost']===null?null:(string)$old['acquisition_unit_cost']);
            $newCondition=(string)($_POST['condition']??'Good');
            if(!in_array($newCondition,['New','Good','Fair','Poor'],true))throw new DomainException('Choose a valid condition for the replacement asset.');
            $ins=$db->prepare("INSERT INTO assignments(product_id,asset_id,quantity,assigned_to,employee_id,employee_record_id,department,location,assigned_by,status,condition_at_assignment,notes) VALUES(?,?,1,?,?,?,?,?,?, 'assigned',?,?)");
            $ins->execute([$new['product_id'],$newId,$person['full_name'],$person['employee_id'],$employeeId,$person['department'],$person['location'],$actor,$newCondition,trim((string)($_POST['notes']??''))?:null]);
            $newAssignment=(int)$db->lastInsertId();
            $db->prepare('INSERT INTO active_hardware_assignments(asset_id,assignment_id) VALUES(?,?)')->execute([$newId,$newAssignment]);
            recordEmployeeAssetStock($db,(int)$new['product_id'],'out','Replacement assignment → '.$person['full_name'].' ('.$person['employee_id'].')','Replacement assignment #'.$newAssignment.' for #'.$oldId,$actor,$new['acquisition_unit_cost']===null?null:(string)$new['acquisition_unit_cost']);
            $db->prepare("UPDATE inventory_assets SET status='assigned',location=? WHERE id=?")->execute([$person['location'],$newId]);
            $db->prepare("INSERT INTO hardware_assignment_history(employee_id,assignment_id,action,reason,old_asset_id,new_asset_id,performed_by) VALUES(?,?,'replaced',?,?,?,?)")
                ->execute([$employeeId,$oldId,$reason,$old['asset_id'],$newId,$actor]);
            audit('hardware_replaced','assignment',$oldId,'Replacement assignment #'.$newAssignment.'; '.$reason);
            setFlash('success','Hardware replaced. Both assignment records were preserved.');
        } elseif ($action === 'hardware_close') {
            $assignmentId=filter_var($_POST['assignment_id']??null,FILTER_VALIDATE_INT,['options'=>['min_range'=>1]]);
            $operation=(string)($_POST['operation']??'');$reason=trim((string)($_POST['reason']??''));
            if(!$assignmentId||!in_array($operation,['returned','removed'],true)||($operation==='removed'&&$reason===''))throw new DomainException('Choose a valid action and enter a removal reason.');
            $q=$db->prepare("SELECT a.id,a.asset_id,a.product_id,ia.acquisition_unit_cost FROM assignments a JOIN inventory_assets ia ON ia.id=a.asset_id WHERE a.id=? AND a.employee_record_id=? AND a.status='assigned' AND a.asset_id IS NOT NULL FOR UPDATE");$q->execute([$assignmentId,$employeeId]);$assignment=$q->fetch();if(!$assignment)throw new DomainException('Only a registered asset assignment can be returned or removed here. Reconcile bulk assignments from Hardware Assets first.');
            $db->prepare('DELETE FROM active_hardware_assignments WHERE assignment_id=?')->execute([$assignmentId]);
            $db->prepare('UPDATE assignments SET status=?,returned_at=NOW() WHERE id=?')->execute([$operation,$assignmentId]);
            recordEmployeeAssetStock($db,(int)$assignment['product_id'],'in','Hardware '.$operation.' → '.$person['full_name'],'Hardware assignment #'.$assignmentId.' '.$operation.($reason!==''?'; '.$reason:''),$actor,$assignment['acquisition_unit_cost']===null?null:(string)$assignment['acquisition_unit_cost']);
            if($assignment['asset_id'])$db->prepare("UPDATE inventory_assets SET status='available' WHERE id=?")->execute([$assignment['asset_id']]);
            $db->prepare('INSERT INTO hardware_assignment_history(employee_id,assignment_id,action,reason,old_asset_id,performed_by) VALUES(?,?,?,?,?,?)')
                ->execute([$employeeId,$assignmentId,$operation,$reason?:null,$assignment['asset_id'],$actor]);
            audit('hardware_'.$operation,'assignment',$assignmentId,$reason?:'Hardware returned');
            setFlash('success',$operation==='returned'?'Hardware return recorded.':'Hardware removed from this employee.');
        } elseif (in_array($action, ['credential_create', 'credential_link', 'credential_update', 'credential_unlink', 'credential_delete'], true)) {
            $softwareId=filter_var($_POST['software_id']??null,FILTER_VALIDATE_INT,['options'=>['min_range'=>1]]);
            if(!$softwareId)throw new DomainException('Select a software record.');
            $softwareLock=$db->prepare("SELECT id,status FROM software_installations WHERE id=? AND employee_id=? FOR UPDATE");$softwareLock->execute([$softwareId,$employeeId]);$softwareRow=$softwareLock->fetch();
            if(!$softwareRow || ($softwareRow['status']!=='installed' && $action!=='credential_unlink' && $action!=='credential_delete'))throw new DomainException('Installed software record was not found.');
            if($action==='credential_create'){
                if($softwareRow['status']!=='installed')throw new DomainException('Credentials can only be added to installed software.');
                requireCredentialEmployeeAccess((int)$employeeId);
                $departmentId=credentialDepartmentForEmployee((int)$employeeId);
                if($departmentId!==null&&!credentialCanAccessDepartment($departmentId))throw new DomainException('You do not have access to this employee department.');
                $entries=normalizeEmployeeCredentialInputs([$_POST['credential']??($_POST['new_credentials'][0]??[])]);
                if(!$entries)throw new DomainException('Enter credential details.');
                $entry=$entries[0];
                $insert=$db->prepare('INSERT INTO credentials(employee_id,department_id,software_installation_id,service_name,service_url,credential_username,credential_password_enc,notes,created_by) VALUES(?,?,?,?,?,?,?,?,?)');
                $insert->execute(employeeSoftwareCredentialInsertValues($entry,(int)$employeeId,$departmentId?(int)$departmentId:null,(int)$softwareId,$actor));
                $credentialId=(int)$db->lastInsertId();auditCredentialChange('credential_created',$credentialId,$entry['service_name']);credentialAccessLog($credentialId,'created');
                setFlash('success','Credential added to software.');
            } else {
                $credentialId=filter_var($_POST['credential_id']??null,FILTER_VALIDATE_INT,['options'=>['min_range'=>1]]);
                if(!$credentialId)throw new DomainException('Credential not found.');
                $credentialQuery=$db->prepare('SELECT * FROM credentials WHERE id=? AND employee_id=? FOR UPDATE');$credentialQuery->execute([$credentialId,$employeeId]);$credential=$credentialQuery->fetch();
                if(!$credential || !credentialCanAccess($credential))throw new DomainException('Credential not found.');
                if($action==='credential_link'){
                    if(!employeeCredentialCanLinkToSoftware($credential,(int)$employeeId,(int)$softwareId))throw new DomainException('Choose an unlinked credential belonging to this employee.');
                    requireCredentialEmployeeAccess((int)$employeeId);
                    $db->prepare('UPDATE credentials SET software_installation_id=?,updated_by=? WHERE id=?')->execute([(int)$softwareId,$actor,(int)$credentialId]);
                    auditCredentialChange('credential_linked',(int)$credentialId,(string)$credential['service_name']);credentialAccessLog((int)$credentialId,'linked');
                    setFlash('success','Existing credential linked to software.');
                } elseif($action==='credential_update'){
                    if((int)$credential['software_installation_id']!==(int)$softwareId)throw new DomainException('Credential is not linked to this software.');
                    $name=trim((string)($_POST['service_name']??''));$username=trim((string)($_POST['credential_username']??''));$password=(string)($_POST['credential_password']??'');$url=trim((string)($_POST['service_url']??''));$notes=trim((string)($_POST['credential_notes']??''));
                    if($name===''||mb_strlen($name)>180||mb_strlen($username)>190||mb_strlen($notes)>4000||strlen($url)>500)throw new DomainException('One or more credential fields are too long or missing.');
                    if($url!==''&&(!filter_var($url,FILTER_VALIDATE_URL)||!in_array(strtolower((string)parse_url($url,PHP_URL_SCHEME)),['http','https'],true)))throw new DomainException('Enter a valid HTTP or HTTPS service URL.');
                    if($password!==''&&strlen($password)>4096)throw new DomainException('Password is too long.');
                    if($password!=='')$db->prepare('INSERT INTO credential_password_versions(credential_id,password_enc,changed_by,change_reason) VALUES(?,?,?,?)')->execute([(int)$credentialId,$credential['credential_password_enc'],$actor,'Password changed']);
                    $sql='UPDATE credentials SET service_name=?,service_url=?,credential_username=?,notes=?,updated_by=?';$params=[$name,$url?:null,$username?:null,$notes?:null,$actor];
                    if($password!==''){$sql.=',credential_password_enc=?';$params[]=encryptCredentialValue($password);}
                    $sql.=' WHERE id=?';$params[]=(int)$credentialId;$db->prepare($sql)->execute($params);
                    if($password!=='')auditCredentialChange('credential_password_changed',(int)$credentialId,$name);
                    auditCredentialChange('credential_updated',(int)$credentialId,$name);credentialAccessLog((int)$credentialId,'edited');setFlash('success','Credential updated.');
                } elseif($action==='credential_unlink'){
                    if((int)$credential['software_installation_id']!==(int)$softwareId)throw new DomainException('Credential is not linked to this software.');
                    $db->prepare('UPDATE credentials SET software_installation_id=NULL,updated_by=? WHERE id=?')->execute([$actor,(int)$credentialId]);
                    auditCredentialChange('credential_unlinked',(int)$credentialId,(string)$credential['service_name']);credentialAccessLog((int)$credentialId,'unlinked');setFlash('success','Credential unlinked. It remains associated with this employee.');
                } else {
                    if((int)$credential['software_installation_id']!==(int)$softwareId)throw new DomainException('Credential is not linked to this software.');
                    $db->prepare('UPDATE credentials SET active=0,updated_by=? WHERE id=?')->execute([$actor,(int)$credentialId]);
                    auditCredentialChange('credential_deleted',(int)$credentialId,(string)$credential['service_name']);credentialAccessLog((int)$credentialId,'deleted');setFlash('success','Credential removed from the active list.');
                }
            }
        } elseif ($action === 'software_add' || $action === 'software_edit') {
            $credentialChoice=employeeSoftwareCredentialChoice((string)($_POST['credential_mode']??''),$_POST['new_credentials']??[],$_POST['link_credential_id']??null);
            $newCredentialEntries=$credentialChoice['entries'];
            if($newCredentialEntries){
                requirePermission('credentials','create');requireCredentialEmployeeAccess((int)$employeeId);
                $credentialDepartment=credentialDepartmentForEmployee((int)$employeeId);
                if($credentialDepartment!==null&&!credentialCanAccessDepartment($credentialDepartment))throw new DomainException('You do not have access to this employee department.');
            } else {
                $credentialDepartment=credentialDepartmentForEmployee((int)$employeeId);
            }
            if($credentialChoice['mode']==='link')requirePermission('credentials','edit');
            $name=trim((string)($_POST['software_name']??''));$version=trim((string)($_POST['version']??''));$license=trim((string)($_POST['license_type']??''));$date=trim((string)($_POST['installation_date']??''));$notes=trim((string)($_POST['software_notes']??''));
            if($name===''||strlen($name)>180||strlen($version)>100||strlen($license)>100)throw new DomainException('Enter valid software details.');
            if($date!==''&&!preg_match('/^\d{4}-\d{2}-\d{2}$/D',$date))throw new DomainException('Enter a valid installation date.');
            if($date!==''){ $parsed=DateTimeImmutable::createFromFormat('!Y-m-d',$date);$errors=DateTimeImmutable::getLastErrors();if(!$parsed||($errors&&($errors['warning_count']||$errors['error_count']))||$parsed->format('Y-m-d')!==$date)throw new DomainException('Enter a valid installation date.'); }
            if($action==='software_add'){
                $s=$db->prepare("INSERT INTO software_installations(employee_id,software_name,version,license_type,installation_date,status,notes,created_by) VALUES(?,?,?,?,?,'installed',?,?)");$s->execute([$employeeId,$name,$version?:null,$license?:null,$date?:null,$notes?:null,$actor]);$softwareId=(int)$db->lastInsertId();$event='added';
            }else{
                $softwareId=filter_var($_POST['software_id']??null,FILTER_VALIDATE_INT,['options'=>['min_range'=>1]]);if(!$softwareId)throw new DomainException('Select a software record.');
                $existing=$db->prepare("SELECT id FROM software_installations WHERE id=? AND employee_id=? AND status='installed' FOR UPDATE");$existing->execute([$softwareId,$employeeId]);if(!$existing->fetchColumn())throw new DomainException('Installed software record was not found.');
                $s=$db->prepare('UPDATE software_installations SET software_name=?,version=?,license_type=?,installation_date=?,notes=? WHERE id=?');$s->execute([$name,$version?:null,$license?:null,$date?:null,$notes?:null,$softwareId]);$event='edited';
            }
            $snapshot=json_encode(['name'=>$name,'version'=>$version,'license_type'=>$license,'installation_date'=>$date,'notes'=>$notes],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
            $db->prepare('INSERT INTO software_history(software_installation_id,employee_id,action,details,performed_by) VALUES(?,?,?,?,?)')->execute([$softwareId,$employeeId,$event,$snapshot,$actor]);
            audit('software_'.$event,'software',$softwareId,$name);
            if($credentialChoice['mode']==='link'){
                requireCredentialEmployeeAccess((int)$employeeId);
                if($credentialDepartment!==null&&!credentialCanAccessDepartment($credentialDepartment))throw new DomainException('You do not have access to this employee department.');
                $credentialQuery=$db->prepare('SELECT * FROM credentials WHERE id=? AND employee_id=? FOR UPDATE');$credentialQuery->execute([$credentialChoice['link_id'],$employeeId]);$credential=$credentialQuery->fetch();
                if(!$credential||!credentialCanAccess($credential)||!employeeCredentialCanLinkToSoftware($credential,(int)$employeeId,(int)$softwareId))throw new DomainException('Choose an unlinked credential belonging to this employee.');
                $db->prepare('UPDATE credentials SET software_installation_id=?,updated_by=? WHERE id=?')->execute([(int)$softwareId,$actor,(int)$credentialChoice['link_id']]);
                auditCredentialChange('credential_linked',(int)$credentialChoice['link_id'],(string)$credential['service_name']);credentialAccessLog((int)$credentialChoice['link_id'],'linked');
            }
            foreach($newCredentialEntries as $entry){
                $credentialInsert=$db->prepare('INSERT INTO credentials(employee_id,department_id,software_installation_id,service_name,service_url,credential_username,credential_password_enc,notes,created_by) VALUES(?,?,?,?,?,?,?,?,?)');
                $credentialInsert->execute(employeeSoftwareCredentialInsertValues($entry,(int)$employeeId,$credentialDepartment?(int)$credentialDepartment:null,(int)$softwareId,$actor));
                $credentialId=(int)$db->lastInsertId();auditCredentialChange('credential_created',$credentialId,$entry['service_name']);credentialAccessLog($credentialId,'created');
            }
            setFlash('success',$event==='added'?'Software added.':'Software details updated.');
        } elseif ($action === 'software_uninstall') {
            $softwareId=filter_var($_POST['software_id']??null,FILTER_VALIDATE_INT,['options'=>['min_range'=>1]]);if(!$softwareId)throw new DomainException('Select a software record.');
            $q=$db->prepare("SELECT software_name FROM software_installations WHERE id=? AND employee_id=? AND status='installed' FOR UPDATE");$q->execute([$softwareId,$employeeId]);$softwareName=$q->fetchColumn();if($softwareName===false)throw new DomainException('Installed software record was not found.');
            $db->prepare("UPDATE software_installations SET status='uninstalled' WHERE id=?")->execute([$softwareId]);
            $db->prepare("INSERT INTO software_history(software_installation_id,employee_id,action,details,performed_by) VALUES(?,?,'uninstalled',?,?)")->execute([$softwareId,$employeeId,(string)($_POST['reason']??''),$actor]);
            audit('software_uninstalled','software',$softwareId,(string)$softwareName);
            setFlash('success','Software uninstall recorded.');
        } else throw new DomainException('Unknown employee profile action.');
        $db->commit();
    } catch (DomainException $e) {
        if($db->inTransaction())$db->rollBack();setFlash('error',$e->getMessage());
    } catch (Throwable $e) {
        if($db->inTransaction())$db->rollBack();error_log('Employee profile update failed (employee_id='.(int)$employeeId.', action='.preg_replace('/[^a-z_]/','',$action).', type='.get_class($e).', code='.$e->getCode().'): '.$e->getMessage());
        setFlash('error','Unable to save the employee change. Please try again.');
    }
    $activeTab = str_starts_with($action,'software_') || str_starts_with($action,'credential_') ? 'software' : 'hardware';
    header('Location: employee.php?id='.(int)$employeeId.'&tab='.$activeTab.'#'.$activeTab);exit;
}

$hardware=[];$hardwareHistory=[];
$employeeHardwareCount=0;
if($canViewHardware){
    $employee=$employee??[];
    $employeeCode=(string)($employee['employee_id']??'');
    $employeeQuantitySql=activeHardwareAssignmentQuantitySql('a');
    $hardwareQ=$db->prepare("SELECT a.id assignment_id,a.asset_id,a.product_id,$employeeQuantitySql quantity,a.assigned_at,a.returned_at,a.status,a.condition_at_assignment,a.notes,p.name asset_name,c.name category_name,ia.asset_tag,ia.serial_number,ia.internal_serial_number,ia.status asset_status,COALESCE(ia.location,a.location,e.location) asset_location,u.full_name assigned_by FROM assignments a JOIN products p ON p.id=a.product_id LEFT JOIN categories c ON c.id=p.category_id LEFT JOIN inventory_assets ia ON ia.id=a.asset_id LEFT JOIN employees e ON e.id=a.employee_record_id LEFT JOIN users u ON u.id=a.assigned_by WHERE (a.employee_record_id=? OR (a.employee_record_id IS NULL AND a.employee_id=?)) AND a.status='assigned' AND a.returned_at IS NULL ORDER BY a.assigned_at DESC,a.id DESC");$hardwareQ->execute([$employeeId,$employeeCode]);$hardware=$hardwareQ->fetchAll();
    $employeeHardwareCount=array_sum(array_map(static fn(array $row):int=>(int)$row['quantity'],$hardware));
    $historyQ=$db->prepare('SELECT h.action,h.reason,h.performed_at,u.full_name performed_by,oldp.name old_asset,newp.name new_asset,oldia.serial_number old_serial,newia.serial_number new_serial FROM hardware_assignment_history h LEFT JOIN users u ON u.id=h.performed_by LEFT JOIN inventory_assets oldia ON oldia.id=h.old_asset_id LEFT JOIN products oldp ON oldp.id=oldia.product_id LEFT JOIN inventory_assets newia ON newia.id=h.new_asset_id LEFT JOIN products newp ON newp.id=newia.product_id WHERE h.employee_id=? ORDER BY h.performed_at DESC,h.id DESC');$historyQ->execute([$employeeId]);$hardwareHistory=$historyQ->fetchAll();
}
$software=[];$softwareHistory=[];
if($canViewSoftware){$softwareQ=$db->prepare('SELECT id,software_name,version,license_type,installation_date,status,notes FROM software_installations WHERE employee_id=? ORDER BY (status="installed") DESC,software_name');$softwareQ->execute([$employeeId]);$software=$softwareQ->fetchAll();$softwareHistoryQ=$db->prepare('SELECT h.action,h.details,h.performed_at,u.full_name performed_by,s.software_name FROM software_history h JOIN software_installations s ON s.id=h.software_installation_id LEFT JOIN users u ON u.id=h.performed_by WHERE h.employee_id=? ORDER BY h.performed_at DESC');$softwareHistoryQ->execute([$employeeId]);$softwareHistory=$softwareHistoryQ->fetchAll();}
$employeeCredentials=[];
if($canViewCredentials&&$canViewSoftware){$credentialsQ=$db->prepare('SELECT c.id,c.employee_id,c.department_id,c.user_id,c.service_name,c.service_url,c.credential_username,c.software_installation_id,c.notes,c.active,si.software_name FROM credentials c LEFT JOIN software_installations si ON si.id=c.software_installation_id WHERE c.employee_id=? AND c.active=1 ORDER BY c.service_name,c.id');$credentialsQ->execute([$employeeId]);foreach($credentialsQ->fetchAll() as $credential){if(credentialCanAccess($credential))$employeeCredentials[]=$credential;}}
require __DIR__ . '/header.php';
?>
<div class="profile-intro"><div><p class="eyebrow">EMPLOYEE PROFILE</p><h2><?=htmlspecialchars($employee['full_name'])?></h2><p class="muted"><?=htmlspecialchars($employee['employee_id'])?> · <?=htmlspecialchars($employee['department']?:'No department')?> · <?=htmlspecialchars($employee['location']?:'No location')?></p></div><a class="btn" href="employees.php">Back to employees</a></div>
<section class="profile-summary card"><div><span>Employee ID</span><strong><?=htmlspecialchars($employee['employee_id'])?></strong></div><div><span>Department</span><strong><?=htmlspecialchars($employee['department']?:'—')?></strong></div><div><span>Location</span><strong><?=htmlspecialchars($employee['location']?:'—')?></strong></div><div><span>Email</span><strong><?= $employee['email']?'<a href="mailto:'.htmlspecialchars($employee['email'],ENT_QUOTES).'">'.htmlspecialchars($employee['email']).'</a>':'—' ?></strong></div><div><span>Employee status</span><strong><?= $employee['active']?'Active':'Inactive' ?></strong></div><div><span>Added</span><strong><?=htmlspecialchars($employee['created_at'])?></strong></div></section>
<div class="profile-tabs" role="tablist" aria-label="Employee assets"><?php if($canViewHardware): ?><a id="hardware-tab" class="profile-tab <?=$activeTab==='hardware'?'active':''?>" href="employee.php?id=<?=$employeeId?>&amp;tab=hardware#hardware" role="tab" aria-selected="<?=$activeTab==='hardware'?'true':'false'?>" aria-controls="hardware" tabindex="<?=$activeTab==='hardware'?'0':'-1'?>">Hardware <span class="count-chip"><?=number_format($employeeHardwareCount)?></span></a><?php endif; ?><?php if($canViewSoftwareTab): ?><a id="software-tab" class="profile-tab <?=$activeTab==='software'?'active':''?>" href="employee.php?id=<?=$employeeId?>&amp;tab=software#software" role="tab" aria-selected="<?=$activeTab==='software'?'true':'false'?>" aria-controls="software" tabindex="<?=$activeTab==='software'?'0':'-1'?>">Software <span class="count-chip"><?=count(array_filter($software,static fn($s)=>$s['status']==='installed'))?></span></a><?php endif; ?></div>
<?php if($canViewHardware): ?><section class="card profile-section" id="hardware" role="tabpanel" aria-labelledby="hardware-tab" <?=$activeTab==='hardware'?'':'hidden'?>> <div class="section-heading"><div><p class="eyebrow">DEVICES & EQUIPMENT</p><h2>Hardware <span class="count-chip"><?=number_format($employeeHardwareCount)?></span></h2></div></div>
<?php if($canAssignHardware): ?>
<div class="hardware-management">
    <div class="hardware-action-buttons" aria-label="Hardware actions">
        <button class="btn btn-glow" type="button" data-hardware-state="assign" aria-controls="assign-hardware-form" aria-expanded="false">Assign Hardware</button>
    </div>
    <div class="hardware-form-panel">
        <form method="post" class="profile-form hardware-action-form" id="assign-hardware-form" hidden>
            <input type="hidden" name="csrf" value="<?=htmlspecialchars(csrf())?>"><input type="hidden" name="employee_id" value="<?=$employeeId?>"><input type="hidden" name="action" value="hardware_assign">
            <div class="form-wide asset-picker" data-asset-picker data-search-url="hardware-assets.php?available_assets=1"><label for="new-asset-search">Search available Inventory hardware</label><input id="new-asset-search" type="search" autocomplete="off" data-asset-search placeholder="Type an asset tag, serial, product or location" aria-autocomplete="list" aria-controls="new-asset-results"><input type="hidden" id="new-asset-id" name="asset_id" required data-asset-id><div id="new-asset-results" class="asset-tag-suggestions" role="listbox" hidden></div><p class="muted" data-asset-selection>No asset selected.</p></div>
            <div><label for="asset-condition">Condition</label><select id="asset-condition" name="condition" required><option>New</option><option selected>Good</option><option>Fair</option><option>Poor</option></select></div>
            <div><label for="assign-reason">Reason</label><input id="assign-reason" name="reason" maxlength="500"></div>
            <div class="form-wide"><label for="asset-notes">Notes</label><textarea id="asset-notes" name="notes"></textarea></div>
            <button class="btn btn-glow" type="submit">Assign asset</button>
        </form>
    </div>
</div>
<script>(function(){const button=document.querySelector('[data-hardware-state="assign"]'),form=document.getElementById('assign-hardware-form');if(button&&form)button.addEventListener('click',function(){const open=form.hidden;form.hidden=!open;button.setAttribute('aria-expanded',String(open));if(open)form.querySelector('[data-asset-search]').focus();});})();</script>
<?php endif; ?>
<div class="table-scroll hardware-assigned-scroll"><table class="hardware-assigned-table"><thead><tr><th>Assigned product</th><th>Asset tag</th><th>Category</th><th>Manufacturer serial number</th><th>Internal serial number</th><th>Assignment date</th><th>Assigned by</th><th>Location</th><th>Condition</th><th>Status</th><?php if($canAssignHardware): ?><th>Actions</th><?php endif; ?></tr></thead><tbody><?php foreach($hardware as $h): ?><tr><td><?=htmlspecialchars($h['asset_name'])?></td><td><?=htmlspecialchars($h['asset_tag']??'—')?></td><td><?=htmlspecialchars($h['category_name']??'—')?></td><td><?=htmlspecialchars($h['serial_number']?:'Pending')?></td><td><?=htmlspecialchars($h['internal_serial_number']?:'—')?></td><td><?=htmlspecialchars($h['assigned_at'])?></td><td><?=htmlspecialchars($h['assigned_by']??'—')?></td><td><?=htmlspecialchars($h['asset_location']??'—')?></td><td><?=htmlspecialchars($h['condition_at_assignment']??'—')?></td><td><span class="state-pill assigned">Assigned</span></td><?php if($canAssignHardware): ?><td class="action-stack hardware-actions-cell"><select class="hardware-action-select" aria-label="Actions for <?=htmlspecialchars($h['asset_name'],ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8')?>" data-hardware-action-select="<?=$h['assignment_id']?>"><option value="" selected>Actions</option><option value="replace">Replace Hardware</option><option value="return">Return Hardware</option><option value="remove">Remove Assignment</option></select>
<dialog class="remove-hardware-dialog" id="replace-hardware-<?=$h['assignment_id']?>" aria-labelledby="replace-hardware-title-<?=$h['assignment_id']?>"><h2 id="replace-hardware-title-<?=$h['assignment_id']?>">Replace assigned hardware</h2><p>Search Inventory for an eligible replacement asset.</p><form method="post" class="remove-hardware-form"><input type="hidden" name="csrf" value="<?=htmlspecialchars(csrf())?>"><input type="hidden" name="employee_id" value="<?=$employeeId?>"><input type="hidden" name="action" value="hardware_replace"><input type="hidden" name="assignment_id" value="<?=$h['assignment_id']?>"><div class="asset-picker" data-asset-picker data-search-url="hardware-assets.php?available_assets=1"><label for="replacement-search-<?=$h['assignment_id']?>">Replacement asset</label><input id="replacement-search-<?=$h['assignment_id']?>" type="search" autocomplete="off" data-asset-search placeholder="Search tag, serial, product or location" aria-autocomplete="list"><input type="hidden" name="asset_id" required data-asset-id><div class="asset-tag-suggestions" role="listbox" hidden></div><p class="muted" data-asset-selection>No asset selected.</p></div><label for="replacement-reason-<?=$h['assignment_id']?>">Reason</label><input id="replacement-reason-<?=$h['assignment_id']?>" name="reason" maxlength="500" required><label for="replacement-condition-<?=$h['assignment_id']?>">New asset condition</label><select id="replacement-condition-<?=$h['assignment_id']?>" name="condition"><option>New</option><option selected>Good</option><option>Fair</option><option>Poor</option></select><div class="remove-hardware-actions"><button class="btn" type="button" data-close-hardware-dialog>Cancel</button><button class="btn btn-glow" type="submit">Confirm Replacement</button></div></form></dialog>
<dialog class="remove-hardware-dialog" id="return-hardware-<?=$h['assignment_id']?>" aria-labelledby="return-hardware-title-<?=$h['assignment_id']?>"><h2 id="return-hardware-title-<?=$h['assignment_id']?>">Return assigned hardware</h2><p>Confirm that this hardware should be returned from the employee.</p><form method="post" class="remove-hardware-form"><input type="hidden" name="csrf" value="<?=htmlspecialchars(csrf())?>"><input type="hidden" name="employee_id" value="<?=$employeeId?>"><input type="hidden" name="assignment_id" value="<?=$h['assignment_id']?>"><input type="hidden" name="operation" value="returned"><input type="hidden" name="action" value="hardware_close"><div class="remove-hardware-actions"><button class="btn" type="button" data-close-hardware-dialog>Cancel</button><button class="btn btn-success" type="submit">Confirm Return</button></div></form></dialog>
<dialog class="remove-hardware-dialog" id="remove-hardware-<?=$h['assignment_id']?>" aria-labelledby="remove-hardware-title-<?=$h['assignment_id']?>"><h2 id="remove-hardware-title-<?=$h['assignment_id']?>">Remove assigned hardware</h2><p>Enter a reason for removing this asset from the employee.</p><form method="post" class="remove-hardware-form"><input type="hidden" name="csrf" value="<?=htmlspecialchars(csrf())?>"><input type="hidden" name="employee_id" value="<?=$employeeId?>"><input type="hidden" name="assignment_id" value="<?=$h['assignment_id']?>"><input type="hidden" name="operation" value="removed"><input type="hidden" name="action" value="hardware_close"><label for="remove-reason-<?=$h['assignment_id']?>">Removal reason</label><input id="remove-reason-<?=$h['assignment_id']?>" name="reason" maxlength="500" required><div class="remove-hardware-actions"><button class="btn" type="button" data-close-hardware-dialog>Cancel</button><button class="btn btn-danger" type="submit">Confirm Remove</button></div></form></dialog></td><?php endif; ?></tr><?php endforeach; ?><?php if(!$hardware): ?><tr><td colspan="<?=($canAssignHardware)?10:9?>" class="empty-state">No hardware is currently assigned to this employee.</td></tr><?php endif; ?></tbody></table></div>
<script>document.addEventListener('change',function(event){const selector=event.target.closest('[data-hardware-action-select]');if(!selector)return;const action=selector.value;selector.value='';if(!action)return;const ids={replace:'replace-hardware-',return:'return-hardware-',remove:'remove-hardware-'};const dialog=document.getElementById(ids[action]+selector.dataset.hardwareActionSelect);if(dialog&&typeof dialog.showModal==='function'){dialog.showModal();const first=dialog.querySelector('input:not([type="hidden"]),select');if(first)first.focus();}});document.addEventListener('click',function(event){const cancel=event.target.closest('[data-close-hardware-dialog]');if(cancel){const dialog=cancel.closest('dialog');if(dialog)dialog.close();}});</script>
<script>(function(){document.querySelectorAll('[data-asset-picker]').forEach(function(picker){const input=picker.querySelector('[data-asset-search]'),hidden=picker.querySelector('[data-asset-id]'),results=picker.querySelector('.asset-tag-suggestions'),selection=picker.querySelector('[data-asset-selection]');let timer;function close(){results.hidden=true;results.replaceChildren();}input.addEventListener('input',function(){hidden.value='';selection.textContent='No asset selected.';clearTimeout(timer);const term=input.value.trim();if(term.length<2){close();return;}timer=setTimeout(async function(){const url=new URL(picker.dataset.searchUrl,location.href);url.searchParams.set('q',term);try{const response=await fetch(url,{headers:{Accept:'application/json'}});if(!response.ok)throw new Error('Asset search unavailable.');const assets=await response.json();results.replaceChildren();assets.forEach(function(asset){const option=document.createElement('button');option.type='button';option.className='asset-tag-option';option.setAttribute('role','option');option.textContent=asset.product_name+' · '+asset.asset_tag+' · manufacturer '+(asset.serial_number||'Pending')+' · internal '+(asset.internal_serial_number||'—')+' · '+(asset.location||'No location');option.addEventListener('click',function(){hidden.value=asset.id;input.value=asset.asset_tag+' · '+asset.product_name;selection.textContent='Selected '+asset.asset_tag+' · '+asset.product_name;close();});results.append(option);});if(!assets.length){const empty=document.createElement('span');empty.className='muted';empty.textContent='No eligible available assets match that search.';results.append(empty);}results.hidden=false;}catch(_){close();}},180);});input.addEventListener('keydown',function(event){if(event.key==='Escape')close();if(event.key==='ArrowDown'){const first=results.querySelector('[role="option"]');if(first){event.preventDefault();first.focus();}}});picker.closest('form').addEventListener('submit',function(event){if(!hidden.value){event.preventDefault();input.setCustomValidity('Search and choose an available asset from Inventory.');input.reportValidity();}else input.setCustomValidity('');});input.addEventListener('input',function(){input.setCustomValidity('');});});})();</script>
<details class="history-disclosure"><summary>Hardware history (<?=count($hardwareHistory)?> events)</summary><div class="table-scroll"><table><thead><tr><th>Action</th><th>Old asset</th><th>New asset</th><th>Reason</th><th>Performed by</th><th>Date</th></tr></thead><tbody><?php foreach($hardwareHistory as $h): ?><tr><td><?=htmlspecialchars(ucfirst($h['action']))?></td><td><?=htmlspecialchars(trim(($h['old_asset']??'').' '.($h['old_serial']??''))?:'—')?></td><td><?=htmlspecialchars(trim(($h['new_asset']??'').' '.($h['new_serial']??''))?:'—')?></td><td><?=htmlspecialchars($h['reason']??'—')?></td><td><?=htmlspecialchars($h['performed_by']??'System')?></td><td><?=htmlspecialchars($h['performed_at'])?></td></tr><?php endforeach; ?><?php if(!$hardwareHistory): ?><tr><td colspan="6" class="empty-state">Hardware events will appear here.</td></tr><?php endif; ?></tbody></table></div></details>
</section><?php endif; ?>

<?php if($canViewSoftwareTab): ?><section class="card profile-section" id="software" role="tabpanel" aria-labelledby="software-tab" <?=$activeTab==='software'?'':'hidden'?>><?php if($canViewSoftware): ?><div class="section-heading"><div><p class="eyebrow">APPLICATIONS & LICENSES</p><h2>Software <span class="count-chip"><?=count(array_filter($software,static fn($s)=>$s['status']==='installed'))?></span></h2></div><?php if($canAddSoftware): ?><button type="button" class="btn btn-glow" id="open-add-software">Add software</button><?php endif; ?></div>
<?php require __DIR__ . DIRECTORY_SEPARATOR . "employee_software_table.php"; ?>
<details class="history-disclosure"><summary>Software history (<?=count($softwareHistory)?> events)</summary><div class="table-scroll"><table><thead><tr><th>Software</th><th>Action</th><th>Details</th><th>Performed by</th><th>Date</th></tr></thead><tbody><?php foreach($softwareHistory as $h): ?><tr><td><?=htmlspecialchars($h['software_name'],ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8')?></td><td><?=htmlspecialchars(ucfirst($h['action']),ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8')?></td><td><code><?=htmlspecialchars($h['details']??'—',ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8')?></code></td><td><?=htmlspecialchars($h['performed_by']??'System',ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8')?></td><td><?=htmlspecialchars($h['performed_at'],ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8')?></td></tr><?php endforeach; ?><?php if(!$softwareHistory): ?><tr><td colspan="5" class="empty-state">Software changes will appear here.</td></tr><?php endif; ?></tbody></table></div></details>
<?php endif; ?>
</section><?php endif; ?>
<?php require __DIR__ . DIRECTORY_SEPARATOR . "employee_software_form.php"; ?>
